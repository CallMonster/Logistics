package com.qianxing.common;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qianxing.communitynanny.R;

/**
 * Created by gong on 2015/7/26.
 */
public class CountDownView extends LinearLayout {
    TextView txt1;
    TextView txt2;
    TextView txt3;
    TextView txt4;
    TextView txt5;
    TextView txt6;

    public CountDownView(Context context)
    {
        super(context);

        init(context);
    }
    public CountDownView(Context context,AttributeSet attrs)
    {
        super(context,attrs);
        init(context);
    }
    public CountDownView(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context,attrs,defStyleAttr);
        init(context);
    }

    void init(Context context)
    {
        View.inflate(context, R.layout.count_down, this);
        txt1 = (TextView) findViewById(R.id.count_down_num1);
        txt2 = (TextView) findViewById(R.id.count_down_num2);
        txt3 = (TextView) findViewById(R.id.count_down_num3);
        txt4 = (TextView) findViewById(R.id.count_down_num4);
        txt5 = (TextView) findViewById(R.id.count_down_num5);
        txt6 = (TextView) findViewById(R.id.count_down_num6);
    }

    public  void  SetDuration(int hours,int minutes,int seconds)
    {
       int totalseconds = hours * 3600 + minutes * 60 + seconds;
        setDuration(totalseconds);
    }
    public void setDuration(int totalSeconds)
    {
        int hours = totalSeconds / 3600;
        int h1 = hours / 10;
        int h2 = hours % 10;

        int minutes = totalSeconds % 3600 / 60;
        int m1 = minutes / 10;
        int m2 = minutes % 10;

        int seconds = totalSeconds % 60;
        int s1 = seconds % 10;
        int s2 = seconds / 10;

        txt1.setText(" " + h1+" ");
        txt2.setText(" " + h2 + " ");
        txt3.setText(" " + m1 + " ");
        txt4.setText(" " + m2 + " ");
        txt5.setText(" " + s1 + " ");
        txt6.setText(" " + s2 + " ");
    }
}
