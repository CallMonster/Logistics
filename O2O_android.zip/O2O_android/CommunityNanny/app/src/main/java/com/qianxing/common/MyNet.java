package com.qianxing.common;

import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by gong on 2015/7/23.
 */
public class MyNet {
    public static RequestQueue requestQueue;

    // 设置网络图片
    public static void setNetImage(final Context context,String url,final ImageView imageView)
    {
        ImageRequest imageRequest = new ImageRequest(url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap bitmap) {
                imageView.setImageBitmap(bitmap);
            }
        },0,0, Bitmap.Config.ARGB_8888,new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(context,"请求网络图片失败:"+volleyError.toString(),Toast.LENGTH_LONG).show();
            }
        }
        );
        requestQueue.add(imageRequest);
    }

//    // callback 是 String 的 Post 请求 (带加密，）
//    public  static void doPost(String url, JSONArray data, final callBackString callback)
//    {
//        final String dataStr = encodeData(data);
//        StringRequest sr = new StringRequest(Request.Method.POST,
//                url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        callback.run(response);
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.i("do post error:",error.toString());
//                    }
//                }
//        ){
//            @Override
//            public byte[] getPostBody() throws AuthFailureError {
//                return this.getBody();
//            }
//
//            @Override
//            public byte[] getBody() throws AuthFailureError {
//                try {
//                    return dataStr.getBytes("utf-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                }
//                return null;
//            }
//        };
//        requestQueue.add(sr);
//    }

    // callback 是 jsonArray 的 post 请求（带加密带解密）
    public static void doPostJsonArray(String url,JSONArray data, final callBackJsonArray callback)
    {
        final String dataStr = encodeData(data);
        StringRequest sr = new StringRequest(Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        callback.run(decodeData(response));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        ){
            @Override
            public byte[] getPostBody() throws AuthFailureError {
                return this.getBody();
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return dataStr.getBytes("utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
        requestQueue.add(sr);
    }

    static String encodeData(JSONArray array)
    {
        String theReturn = null;
        String str = array.toString();
        // str aes 加密
        str = AesEncode.encrypt(str,"111111");
        try {
            JSONObject object = new JSONObject();
            object.put("data",str);
            JSONArray newArray = new JSONArray();
            newArray.put(object);
            theReturn = newArray.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return theReturn;
    }

    static JSONArray decodeData(String data)
    {
        try {
            JSONArray array = new JSONArray(data);
            JSONObject object = array.getJSONObject(0);
            String str = object.get("data").toString();
            // str aes 解密
            str = AesEncode.decrypt(str,"111111");
            JSONArray array1 = new JSONArray(str);
            return array1;

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;

    }
}
