package com.qianxing.common;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.qianxing.communitynanny.R;
import com.qianxing.communitynanny.UserData;

import java.util.List;

/**
 * Created by gong on 2015/7/24.
 */
public class SimpleDialog extends Dialog {

    View.OnClickListener onclickleft;
    View.OnClickListener onclickright;

    TextView msgTxt;
    TextView rightTxt;
    TextView leftTxt;

    String strLeft;
    String strRight;

    String strMsg;

    public SimpleDialog(Context context,String msg,String left,String right)
    {
        super(context,R.style.simple_dialog_style);
        strMsg = msg;
        strLeft = left;
        strRight = right;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.simple_dialog);

        msgTxt = (TextView)findViewById(R.id.simple_dialog_msg);
        rightTxt = (TextView)findViewById(R.id.simple_dialog_right);
        leftTxt = (TextView)findViewById(R.id.simple_dialog_left);

        msgTxt.setText(strMsg);
        rightTxt.setText(strRight);
        leftTxt.setText(strLeft);

        rightTxt.setClickable(true);
        leftTxt.setClickable(true);

        WindowManager.LayoutParams params = this.getWindow().getAttributes();
        params.width = Integer.parseInt(UserData.get("screen_width")) * 6 / 10;
        Log.i("屏幕宽度：",UserData.get("screen_width"));
        this.getWindow().setAttributes(params);

        leftTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onclickleft.onClick(v);
            }
        });
        rightTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onclickright.onClick(v);
            }
        });
    }

    public  void SetOnClickLeft(View.OnClickListener  listener)
    {
        onclickleft = listener;
    }

    public void SetOnClickRight(View.OnClickListener listener)
    {
        onclickright = listener;
    }
}
