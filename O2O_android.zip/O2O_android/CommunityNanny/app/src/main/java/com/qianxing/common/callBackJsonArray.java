package com.qianxing.common;

import org.json.JSONArray;

/**
 * Created by gong on 2015/7/26.
 */
public interface callBackJsonArray {
    public void run(JSONArray array);
}
