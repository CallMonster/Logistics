package com.qianxing.common;

/**
 * Created by gong on 2015/7/25.
 */
public interface callBackString {

    public  void run(String string);
}
