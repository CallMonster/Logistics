package com.qianxing.communitynanny;

import android.app.Activity;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class EditAddressActivity extends Activity {

    View back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_address);

        getAllView();
        init();
    }

    void getAllView()
    {
        back = (View) findViewById(R.id.back);
    }

    void init()
    {
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditAddressActivity.this.finish();
            }
        });
    }
}
