package com.qianxing.communitynanny;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;


public class GiftCertificate extends Activity {

    View back;
    View codeOk;
    View gift;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift_certificate);

        getAllView();
        init();

    }

    void getAllView()
    {
        back = (View) findViewById(R.id.back);
        gift = (View) findViewById(R.id.gift_layout);
        codeOk = (View) findViewById(R.id.ok);
    }

    void init()
    {
        // 返回
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GiftCertificate.this.finish();
            }
        });

        // 礼券码确认
        codeOk.setClickable(true);
        codeOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gift.setVisibility(View.VISIBLE);
            }
        });

        // 礼券不默认不显示
        gift.setVisibility(View.INVISIBLE);

    }

}
