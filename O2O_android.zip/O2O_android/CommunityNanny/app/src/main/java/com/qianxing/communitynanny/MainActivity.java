package com.qianxing.communitynanny;

import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
//import  android.app.Fragment;
import android.hardware.display.DisplayManager;
import android.os.Debug;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.toolbox.Volley;
import com.qianxing.common.MyNet;
import com.qianxing.common.SimpleDialog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.Duration;


public class MainActivity extends FragmentActivity {

    ViewPager mPager;
    ArrayList<Fragment> fragmentList;
    RadioGroup radioGroup;

    int[] group_idx2id = new int[4];         // 索引到 radio id 的映射
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MyNet.requestQueue = Volley.newRequestQueue(getApplicationContext());

        DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        int width = metric.widthPixels;  // 宽度（PX）
        int height = metric.heightPixels;  // 高度（PX）
        UserData.set("screen_height", height + "");
        UserData.set("screen_width", width + "");

        initViewPager();


        group_idx2id[0] = R.id.radio_menu;
        group_idx2id[1] = R.id.radio_order;
        group_idx2id[2] = R.id.radio_vip;
        group_idx2id[3] = R.id.radio_user;
    }

    void initViewPager()
    {
        mPager = (ViewPager)findViewById(R.id.frameViewPager);
        radioGroup = (RadioGroup)findViewById(R.id.menuGroup);
        radioGroup.check(R.id.radio_menu);
        radioGroup.setOnCheckedChangeListener(new checkChange());
        fragmentList = new ArrayList<Fragment>();
        Fragment mainPage = new mainPage();
        Fragment orderPage = new orderPage();
        Fragment vipPage = new vipPage();
        Fragment userPage = new userPage();
        fragmentList.add(mainPage);
        fragmentList.add(orderPage);
        fragmentList.add(vipPage);
        fragmentList.add(userPage);
        mPager.setAdapter(new MyAdpather());
        mPager.setCurrentItem(0);
    }




    @Override
    protected void onResume() {
        super.onResume();
        if(!UserData.get("witchPage").equals(""))
        {
            String witch = UserData.get("witchPage");
            int wch = Integer.parseInt(witch);
            mPager.setCurrentItem(wch);
            radioGroup.check(group_idx2id[wch]);
            UserData.set("witchPage","");
        }
    }

    class MyAdpather extends FragmentPagerAdapter
    {
        public MyAdpather()
        {
            super(getSupportFragmentManager());
        }
        @Override
        public  int getCount()
        {
            return fragmentList.size();
        }
        @Override
        public android.support.v4.app.Fragment getItem(int idx)
        {
            return fragmentList.get(idx);
        }
    }

    class checkChange implements RadioGroup.OnCheckedChangeListener
    {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId)
        {
//            Toast.makeText(MainActivity.this,"radio group:" + group + " id:" + checkedId, Toast.LENGTH_LONG).show();
//            mPager.setCurrentItem(checkedId);
            switch (checkedId)
            {
                case R.id.radio_menu:
                {
                    mPager.setCurrentItem(0);
                }break;
                case R.id.radio_order:
                {
                    mPager.setCurrentItem(1);
                }break;
                case R.id.radio_vip:
                {
                    mPager.setCurrentItem(2);
                }break;
                case R.id.radio_user:
                {
                    mPager.setCurrentItem(3);
                }break;
            }
        }
    }



}
