package com.qianxing.communitynanny;

import android.app.Activity;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class OrderRemarkActivity extends Activity {

    View back;
    View submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_remark);

        getAllView();
        init();
    }

    void getAllView()
    {
        back = (View) findViewById(R.id.back);
        submitButton = (View) findViewById(R.id.submit);
    }

    void init()
    {
        // 设置 返回监听
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OrderRemarkActivity.this.finish();
            }
        });

        // 设置 确定 监听
        submitButton.setClickable(true);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OrderRemarkActivity.this.finish();
            }
        });
    }

}
