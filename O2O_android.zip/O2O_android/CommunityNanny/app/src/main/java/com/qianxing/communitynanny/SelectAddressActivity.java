package com.qianxing.communitynanny;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class SelectAddressActivity extends Activity {

    View back;
    View addAddr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_address);

        findAllViews();
        init();
    }

    void findAllViews()
    {
        back = (View) findViewById(R.id.back);
        addAddr = (View) findViewById(R.id.addAddress);
    }

    void init()
    {
        back.setClickable(true);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectAddressActivity.this.finish();
            }
        });

        addAddr.setClickable(true);
        addAddr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectAddressActivity.this,EditAddressActivity.class);
                startActivity(intent);
            }
        });
    }

}
