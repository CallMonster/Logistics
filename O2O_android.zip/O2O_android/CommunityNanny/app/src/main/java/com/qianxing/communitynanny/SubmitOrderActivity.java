package com.qianxing.communitynanny;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;


public class SubmitOrderActivity extends Activity {

    FrameLayout addr; // 地址条，点击选择地址

    TextView addr0;// 选择地址
    TextView addr1;// 地址第一行
    TextView addr2;// 地址第二行

    View giftCode; // 礼券

    View orderRemark; // 送餐备注
    CheckBox needBill; // 需要发票
    View inputBillTitle; // 发票抬头输入框

    View toPay;  // 去支付

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_order);

        getAllView();
        init();
    }

    void getAllView()
    {
        addr = (FrameLayout) findViewById(R.id.submit_order_addr);

        addr0 = (TextView) findViewById(R.id.submit_order_address0);
        addr1 = (TextView) findViewById(R.id.submit_order_address1);
        addr2 = (TextView) findViewById(R.id.submit_order_address2);

        orderRemark = (View) findViewById(R.id.order_remark);

        giftCode = (View) findViewById(R.id.gift);

        needBill = (CheckBox) findViewById(R.id.need_bill);
        inputBillTitle = (View) findViewById(R.id.input_bill_title);

        toPay = (View)findViewById(R.id.to_pay);
    }

    void init()
    {
        // 地址的监听
        addr.setClickable(true);
        addr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubmitOrderActivity.this, SelectAddressActivity.class);
                startActivity(intent);
            }
        });
        // 隐藏"选择地址"
        addr0.setVisibility(View.GONE);

        // 送餐备注的监听
        orderRemark.setClickable(true);
        orderRemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubmitOrderActivity.this,OrderRemarkActivity.class);
                startActivity(intent);
            }
        });

        // 礼券 监听
        giftCode.setClickable(true);
        giftCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubmitOrderActivity.this, GiftCertificate.class);
                startActivity(intent);
            }
        });

        // 需要发票
        needBill.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                    inputBillTitle.setVisibility(View.VISIBLE);
                else
                    inputBillTitle.setVisibility(View.GONE);
            }
        });
        inputBillTitle.setVisibility(View.GONE);

        // 去支付
        toPay.setClickable(true);
        toPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserData.set("witchPage","1");
                Toast.makeText(SubmitOrderActivity.this,"支付成功",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SubmitOrderActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }

}
