package com.qianxing.communitynanny;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by gong on 2015/7/22.
 */
public class UserData {
    static HashMap<String,String> map = new HashMap<String,String>();
    public  static  void set(String key,String value){
        map.put(key,value);

    }
    public static String get(String key)
    {
        if(map.containsKey(key))
            return map.get(key);
        else
            return "";
    }

}
