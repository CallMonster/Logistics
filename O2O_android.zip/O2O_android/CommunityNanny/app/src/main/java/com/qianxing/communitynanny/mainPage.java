package com.qianxing.communitynanny;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.Fragment;
//import android.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.qianxing.common.MyViewPager;
import com.qianxing.common.SimpleDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class mainPage extends Fragment {
    public mainPage() {
        // Required empty public constructor
    }

    MyViewPager vp;
    int totalImage = 0;
    int nowImage =0;
    ArrayList<ImageView> imageList;
    ArrayList<ImageView> dotList;

    Timer timer = new Timer();
    RadioGroup dotGroup;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_main_page,container,false);
        //  the city
        TextView city = (TextView) rootView.findViewById(R.id.theCity);
        city.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), CityActivity.class);
                startActivity(intent);
            }
        });
        // the banner
        vp = (MyViewPager) rootView.findViewById(R.id.main_banner);
        vp.setNoScroll(false);
        int[] ids = new int[]{R.drawable.item1,R.drawable.item2, R.drawable.item3};
        imageList = new ArrayList<ImageView>();
        for(int i =0;i<ids.length;i++) {
            ImageView iv = new ImageView(getActivity());
            imageList.add(iv);
            iv.setBackgroundResource(ids[i]);
            totalImage++;
        }
        vp.addOnPageChangeListener(new scollListener());
        vp.setAdapter(new myAdpater());
        // 定时

        // timer
        final android.os.Handler handler = new android.os.Handler() {
            @Override
            public void handleMessage(Message msg) {
                if(msg.what == 1)
                {
                    vp.setCurrentItem((nowImage + 1) % totalImage);
                }
                super.handleMessage(msg);
            }
        };
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Message msg = new Message();
                msg.what =1;
                handler.sendMessage(msg);
            }
        };
        timer.schedule(task,5000,5000);

        // dot
        dotGroup = (RadioGroup)rootView.findViewById(R.id.dotGroup);
        for(int i =0;i<imageList.size();i++)
        {
            RadioButton rb = new RadioButton(getActivity());
            rb.setButtonDrawable(R.drawable.nullpic);
            rb.setClickable(false);
            rb.setLayoutParams(new ViewGroup.LayoutParams(20, 20));
            rb.setBackgroundResource(R.drawable.dot_radio);
            dotGroup.addView(rb);
            if(i ==0)rb.setChecked(true);
            else rb.setChecked(false);
        }

        //service call
        ImageView serviceCall = (ImageView)rootView.findViewById(R.id.serviceCall);
        serviceCall.setClickable(true);
        serviceCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final SimpleDialog dialog = new SimpleDialog(getActivity(),"what's the fuck","取消","呼叫");
                dialog.SetOnClickLeft(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getActivity(), "you clicked the left button", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });
                dialog.SetOnClickRight(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getActivity(), "you clicked the right button", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        return rootView;
    }
    class myAdpater extends PagerAdapter
    {
        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public int getCount() {
            return imageList.size();
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(imageList.get(position));
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(imageList.get(position));
            return imageList.get(position);
        }
    }
    class scollListener implements ViewPager.OnPageChangeListener
    {
        @Override
        public void onPageSelected(int position) {
            nowImage = position;
            dotGroup.check(position + 1);
        }

        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }
    }
}
