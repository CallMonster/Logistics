package com.qianxing.communitynanny;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.qianxing.common.CountDownView;
import com.qianxing.common.MyNet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class userPage extends Fragment {


    public userPage() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_user_page, container, false);
        ImageView image = (ImageView) rootView.findViewById(R.id.user_test);
//        MyNet.setNetImage(getActivity(),"http://192.168.0.103/test/p.jpg",image);



        return rootView;
    }



}
