package com.qianxing.communitynanny;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.qianxing.common.callBackString;
import com.qianxing.common.callBackJsonArray;

import com.qianxing.common.MyNet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


/**
 * A simple {@link Fragment} subclass.
 */
public class vipPage extends Fragment {


    public vipPage() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView =inflater.inflate(R.layout.fragment_vip_page, container, false);
        final TextView txt = (TextView)rootView.findViewById(R.id.tttt);

        JSONArray array = new JSONArray();

        try {
            JSONObject object = new JSONObject();
            object.put("type","");
            JSONArray data = new JSONArray();
        } catch (JSONException e) {
            e.printStackTrace();
        }
//        http://[DOMAIN/IP]/O2O/Info/dataInfo
//        192.168.0.109
        MyNet.doPostJsonArray("http://192.168.0.109/O2OC/VInterface/init", array, new callBackJsonArray() {
            @Override
            public void run(JSONArray array) {
                txt.setText(array.toString());
            }
        });
        return rootView;
    }


}
